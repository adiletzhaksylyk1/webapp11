package com.example.todolistapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> tasks;
    private ArrayAdapter<String> adapter;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tasks = new ArrayList<>();
        ListView listView = findViewById(R.id.listView);
        editText = findViewById(R.id.editText);
        Button addButton = findViewById(R.id.addButton);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                tasks);
        listView.setAdapter(adapter);

        addButton.setOnClickListener(view -> {
            String taskText = editText.getText().toString().trim();
            if (!taskText.isEmpty()) {
                tasks.add(taskText);
                adapter.notifyDataSetChanged();
                editText.setText("");
                Toast.makeText(MainActivity.this,
                        "Task added!",
                        Toast.LENGTH_SHORT).show();
            }
        });

        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            tasks.remove(position);
            adapter.notifyDataSetChanged();
            Toast.makeText(MainActivity.this,
                    "Task removed!",
                    Toast.LENGTH_SHORT).show();
            return true;
        });
    }
}